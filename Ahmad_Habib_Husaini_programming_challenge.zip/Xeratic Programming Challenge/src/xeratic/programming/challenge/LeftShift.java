package xeratic.programming.challenge;

public class LeftShift {
  public static int calculate(int x, int y) {
      System.out.println("Menghitung " + x + " << " + y);
      
      return x * (y*y);
  }
}
